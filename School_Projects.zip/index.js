alert("You can only proceed if you are a die-hard fan of One Piece");

function blu() {
  
  var gradient = "radial-gradient(circle, #19788f, #205c9f)";
  
  
  document.getElementById("footer").style.background = gradient;
  
  document.getElementById("about").style.background=gradient;
  
    document.getElementById("advertise").style.background="#19788f";

   document.getElementById("spam").style.background="#19788f";

  document.getElementById("About_One-piece").style.background = "59656d";
  
  document.getElementById("header").style.background = gradient; 
  
  document.getElementById("nav").style.backgroundColor = "#1560BD";
  
  document.getElementById("img1").style.opacity = "1";
}
